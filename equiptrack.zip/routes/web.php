
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EquipmentController;

// Dashboard
Route::get('/', [EquipmentController::class, 'index']);
// Equipment Inventory Page
Route::get('/equipment', [EquipmentController::class, 'inventory'])
    ->name('equipment.index');
    // Add Equipment Page
Route::get('/equipment/create', [EquipmentController::class, 'create'])
    ->name('equipment.create');

// Add Equipment
Route::post('/equipment', [EquipmentController::class, 'store'])
    ->name('equipment.store');

// Edit Equipment
Route::put('/equipment/{id}', [EquipmentController::class, 'update'])
    ->name('equipment.update');

// Delete Equipment
Route::delete('/equipment/{id}', [EquipmentController::class, 'destroy'])
    ->name('equipment.destroy');
