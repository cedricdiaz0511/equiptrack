<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Equipment;

class EquipmentController extends Controller
{
    // DASHBOARD
    public function index()
    {
        $equipments = Equipment::all();

        return view('dashboard', compact('equipments'));
    }

    // EQUIPMENT INVENTORY
    public function inventory()
    {
        $equipments = Equipment::all();

        return view('equipments.index', compact('equipments'));
    }

    // ADD EQUIPMENT PAGE
    public function create()
    {
        return view('equipments.create');
    }

    // EDIT EQUIPMENT PAGE
    public function edit($id)
    {
        $equipment = Equipment::findOrFail($id);

        return view('equipments.edit', compact('equipment'));
    }

    // ANALYTICS PAGE
    public function analytics()
    {
        $equipments = Equipment::all();

        return view('analytics', compact('equipments'));
    }

    // SETTINGS PAGE
    public function settings()
    {
        return view('settings');
    }

    // SAVE NEW EQUIPMENT
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'category' => 'required|string|max:255',
            'description' => 'nullable|string',
            'status' => 'required|string',
            'quantity' => 'required|integer|min:1',
        ]);

        $validated['quantity'] = (int) $validated['quantity'];

            Equipment::create($validated);

        return redirect('/')
            ->with('success', 'Equipment added successfully!');
    }

    // UPDATE EQUIPMENT
    public function update(Request $request, $id)
    {
        $equipment = Equipment::findOrFail($id);

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'category' => 'required|string|max:255',
            'description' => 'nullable|string',
            'status' => 'required|string',
            'quantity' => 'required|integer|min:1',
        ]);

        $validated['quantity'] = (int) $validated['quantity'];

        $equipment->update($validated);

        return redirect('/')
            ->with('success', 'Equipment updated successfully!');
    }

    // DELETE EQUIPMENT
    public function destroy($id)
    {
        $equipment = Equipment::findOrFail($id);

        $equipment->delete();

        return redirect('/')
            ->with('success', 'Equipment deleted successfully!');
    }
}
