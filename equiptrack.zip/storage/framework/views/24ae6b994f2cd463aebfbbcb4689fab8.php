
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EquipTrack Dashboard</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        .sidebar {
            width: 240px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: #0f172a;
            color: white;
            padding: 25px 15px;
            z-index: 100;
        }

        .sidebar h2 {
            color: #38bdf8;
            text-align: center;
            margin-bottom: 40px;
        }

        .sidebar a {
            display: block;
            padding: 15px;
            color: #cbd5e1;
            text-decoration: none;
            border-radius: 8px;
            margin-bottom: 8px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: #2563eb;
            color: white;
        }

        .main {
            margin-left: 240px;
            padding: 35px;
            min-height: 100vh;
            width: calc(100% - 240px);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin-bottom: 10px;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-top: 30px;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 12px #00000010;
        }

        .card h3 {
            color: #64748b;
            font-size: 15px;
        }

        .card h1 {
            font-size: 34px;
            margin-bottom: 0;
        }

        .success {
            background: #dcfce7;
            color: #166534;
            padding: 12px;
            border-radius: 7px;
            margin-top: 15px;
        }

        .error {
            color: #dc2626;
            font-size: 13px;
            margin-top: 5px;
        }

        .welcome-box {
            background: white;
            padding: 25px;
            margin-top: 35px;
            border-radius: 12px;
            box-shadow: 0 4px 12px #00000008;
        }

        .welcome-box h2 {
            margin-top: 0;
        }

        @media (max-width: 1100px) {
            .cards {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 600px) {
            .sidebar {
                position: static;
                width: 100%;
                height: auto;
            }

            .main {
                margin-left: 0;
                width: 100%;
                padding: 20px;
            }

            .cards {
                grid-template-columns: 1fr;
            }

            .header {
                flex-wrap: wrap;
                gap: 10px;
            }
        }
    </style>
</head>

<body>

    <!-- SIDEBAR -->
    <div class="sidebar">

        <h2>⚙ EquipTrack</h2>

        <a href="<?php echo e(url('/')); ?>" class="active">
            📊 Dashboard
        </a>

        <a href="<?php echo e(route('equipment.index')); ?>">
            🖥 Equipment Inventory
        </a>

        <a href="<?php echo e(route('equipment.create')); ?>">
            ➕ Add Equipment
        </a>

        <a href="<?php echo e(url('/analytics')); ?>">
            📈 Analytics
        </a>

        <a href="<?php echo e(url('/settings')); ?>">
            ⚙ Settings
        </a>

    </div>

    <!-- MAIN CONTENT -->
    <div class="main">

        <!-- HEADER -->
        <div class="header">

            <div>
                <h1>Dashboard</h1>
                <p>Welcome to EquipTrack Equipment Management System</p>
            </div>

            <strong>Administrator</strong>

        </div>

        <!-- SUCCESS MESSAGE -->
        <?php if(session('success')): ?>
            <div class="success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- ERROR MESSAGE -->
        <?php if($errors->any()): ?>
            <div class="error">
                Please check the form. Some information is missing or invalid.
            </div>
        <?php endif; ?>

        <!-- DASHBOARD SUMMARY CARDS -->
        <div class="cards">

            <div class="card">
                <h3>Total Equipment</h3>
                <h1><?php echo e($equipments->sum('quantity')); ?></h1>
            </div>

            <div class="card">
                <h3>Available Equipment</h3>
                <h1>
                    <?php echo e($equipments->where('status', 'Available')->sum('quantity')); ?>

                </h1>
            </div>

            <div class="card">
                <h3>Borrowed Equipment</h3>
                <h1>
                    <?php echo e($equipments->where('status', 'Borrowed')->sum('quantity')); ?>

                </h1>
            </div>

            <div class="card">
                <h3>Under Maintenance</h3>
                <h1>
                    <?php echo e($equipments->where('status', 'Under Maintenance')->sum('quantity')); ?>

                </h1>
            </div>

        </div>

        <!-- WELCOME SECTION -->
        <div class="welcome-box">

            <h2>Welcome to EquipTrack!</h2>

            <p>
                Your Equipment Management System is ready.
            </p>

            <p>
                Use the sidebar navigation to manage your equipment.
            </p>

            <p>
                You can view your equipment inventory, add new equipment,
                monitor analytics, and manage system settings.
            </p>

        </div>

    </div>

</body>
</html>
<?php /**PATH C:\Users\Cedric\equiptrack\resources\views/dashboard.blade.php ENDPATH**/ ?>