<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equipment Inventory | EquipTrack</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            background: #f1f5f9;
            color: #172b4d;
        }

        .sidebar {
            width: 240px;
            min-height: 100vh;
            background: #0f172a;
            padding: 30px 18px;
            position: fixed;
            left: 0;
            top: 0;
        }

        .sidebar h2 {
            color: #22b8ff;
            margin-bottom: 40px;
        }

        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 8px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: #2563eb;
        }

        .main {
            margin-left: 240px;
            padding: 40px 32px;
            width: calc(100% - 240px);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .header h1 {
            font-size: 30px;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 25px;
            box-shadow: 0 4px 12px rgba(0,0,0,.05);
        }

        .card h2 {
            margin-bottom: 20px;
        }

        .search {
            width: 100%;
            padding: 12px;
            border: 1px solid #cbd5e1;
            border-radius: 7px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 16px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }

        th {
            background: #f8fafc;
        }

        .edit {
            background: #f59e0b;
            color: white;
            border: none;
            padding: 9px 14px;
            border-radius: 6px;
            cursor: pointer;
        }

        .delete {
            background: #ef4444;
            color: white;
            border: none;
            padding: 9px 14px;
            border-radius: 6px;
            cursor: pointer;
        }

        .back {
            display: inline-block;
            background: #2563eb;
            color: white;
            padding: 11px 18px;
            text-decoration: none;
            border-radius: 7px;
            margin-bottom: 20px;
        }

        @media(max-width: 800px) {
            .sidebar {
                width: 180px;
            }

            .main {
                margin-left: 180px;
                width: calc(100% - 180px);
                padding: 20px;
                overflow-x: auto;
            }
        }
    </style>
</head>

<body>

<div class="sidebar">

    <h2>⚙ EquipTrack</h2>

    <a href="/">📊 Dashboard</a>

    <a href="<?php echo e(route('equipment.index')); ?>" class="active">
        ▤ Equipment Inventory
    </a>

    <a href="/#add-equipment">➕ Add Equipment</a>

    <a href="/#analytics">📈 Analytics</a>

    <a href="/#settings">⚙ Settings</a>

</div>

<div class="main">

    <div class="header">
        <div>
            <h1>Equipment Inventory</h1>
            <p>Manage and monitor all your equipment.</p>
        </div>

        <strong>Administrator</strong>
    </div>

    <a href="/" class="back">← Back to Dashboard</a>

    <?php if(session('success')): ?>
        <div style="background:#dcfce7;color:#166534;padding:15px;
                    border-radius:8px;margin-bottom:20px;">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="card">

        <h2>📦 Equipment List</h2>

        <input
            type="text"
            id="searchInput"
            class="search"
            placeholder="Search equipment..."
            onkeyup="searchEquipment()"
        >

        <div style="overflow-x:auto;">

            <table id="equipmentTable">

                <thead>
                    <tr>
                        <th>Equipment Name</th>
                        <th>Category</th>
                        <th>Status</th>
                        <th>Quantity</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $equipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>
                        <td><?php echo e($equipment->name); ?></td>

                        <td><?php echo e($equipment->category); ?></td>

                        <td><?php echo e($equipment->status); ?></td>

                        <td><?php echo e($equipment->quantity); ?></td>

                        <td><?php echo e($equipment->description); ?></td>

                        <td>
                            <button
                                class="edit"
                                onclick="editEquipment(
                                    '<?php echo e($equipment->id); ?>',
                                    <?php echo e(Js::from($equipment->name)); ?>,
                                    <?php echo e(Js::from($equipment->category)); ?>,
                                    <?php echo e(Js::from($equipment->status)); ?>,
                                    '<?php echo e($equipment->quantity); ?>',
                                    <?php echo e(Js::from($equipment->description ?? '')); ?>

                                )">
                                ✏️ Edit
                            </button>

                            <form
                                action="<?php echo e(route('equipment.destroy', $equipment->id)); ?>"
                                method="POST"
                                style="display:inline;"
                                onsubmit="return confirm('Are you sure you want to delete this equipment?')">

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button type="submit" class="delete">
                                    🗑 Delete
                                </button>

                            </form>
                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>
                        <td colspan="6" style="text-align:center;">
                            No equipment records found.
                        </td>
                    </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<!-- EDIT MODAL -->

<div id="editModal"
     style="display:none;position:fixed;inset:0;
            background:rgba(0,0,0,.6);z-index:1000;
            justify-content:center;align-items:center;padding:20px;">

    <div style="background:white;padding:30px;border-radius:12px;
                width:100%;max-width:500px;">

        <h2 style="margin-bottom:20px;">Edit Equipment</h2>

        <form id="editForm" method="POST">

            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <label>Equipment Name</label>
            <input type="text" id="editName" name="name"
                   required style="width:100%;padding:10px;margin:8px 0 15px;">

            <label>Category</label>
            <input type="text" id="editCategory" name="category"
                   required style="width:100%;padding:10px;margin:8px 0 15px;">

            <label>Status</label>
            <select id="editStatus" name="status"
                    required style="width:100%;padding:10px;margin:8px 0 15px;">

                <option value="Available">Available</option>
                <option value="Borrowed">Borrowed</option>
                <option value="Under Maintenance">Under Maintenance</option>

            </select>

            <label>Quantity</label>
            <input type="number" id="editQuantity" name="quantity"
                   min="1" required
                   style="width:100%;padding:10px;margin:8px 0 15px;">

            <label>Description</label>
            <textarea id="editDescription" name="description"
                      style="width:100%;padding:10px;margin:8px 0 15px;"></textarea>

            <button type="submit"
                    style="background:#2563eb;color:white;padding:11px 20px;
                           border:0;border-radius:6px;cursor:pointer;">
                Save Changes
            </button>

            <button type="button"
                    onclick="closeModal()"
                    style="padding:11px 20px;border:0;border-radius:6px;
                           cursor:pointer;">
                Cancel
            </button>

        </form>

    </div>

</div>

<script>

function searchEquipment() {

    let input = document.getElementById("searchInput");
    let filter = input.value.toLowerCase();

    let rows = document.querySelectorAll("#equipmentTable tbody tr");

    rows.forEach(function(row) {

        let text = row.innerText.toLowerCase();

        row.style.display = text.includes(filter) ? "" : "none";

    });

}

function editEquipment(id, name, category, status, quantity, description) {

    document.getElementById('editForm').action =
        '/equipment/' + encodeURIComponent(id);

    document.getElementById('editName').value = name;
    document.getElementById('editCategory').value = category;
    document.getElementById('editStatus').value = status;
    document.getElementById('editQuantity').value = quantity;
    document.getElementById('editDescription').value = description;

    document.getElementById('editModal').style.display = 'flex';

}

function closeModal() {

    document.getElementById('editModal').style.display = 'none';

}

</script>

</body>
</html><?php /**PATH C:\Users\Cedric\equiptrack\resources\views/equipments/index.blade.php ENDPATH**/ ?>