
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Equipment | EquipTrack</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f1f5f9;
            color: #172554;
        }

        .sidebar {
            width: 235px;
            height: 100vh;
            background: #0f172a;
            position: fixed;
            padding: 25px 18px;
            color: white;
        }

        .brand {
            color: #22b8f0;
            font-size: 24px;
            font-weight: bold;
            margin: 10px 0 40px;
        }

        .sidebar a {
            display: block;
            padding: 15px;
            margin-bottom: 10px;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }

        .sidebar a:hover,
        .sidebar .active {
            background: #2563eb;
        }

        .main {
            margin-left: 235px;
            padding: 40px 30px;
            min-height: 100vh;
        }

        .top {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
        }

        .top h1 {
            font-size: 30px;
            margin-bottom: 8px;
        }

        .card {
            background: white;
            padding: 30px;
            border-radius: 13px;
            box-shadow: 0 5px 15px rgba(0,0,0,.05);
            max-width: 1000px;
        }

        .card h2 {
            margin-bottom: 25px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .full {
            grid-column: 1 / -1;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 9px;
        }

        input, select, textarea {
            width: 100%;
            padding: 13px;
            border: 1px solid #cbd5e1;
            border-radius: 7px;
            font-size: 15px;
        }

        textarea {
            height: 110px;
            resize: vertical;
        }

        .btn {
            padding: 13px 22px;
            border: none;
            border-radius: 7px;
            color: white;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-size: 15px;
        }

        .save {
            background: #2563eb;
        }

        .back {
            background: #64748b;
            margin-right: 8px;
        }

        .save:hover {
            background: #1d4ed8;
        }

        .errors {
            background: #fee2e2;
            color: #991b1b;
            padding: 15px;
            border-radius: 7px;
            margin-bottom: 20px;
        }

        @media(max-width: 750px) {
            .sidebar {
                width: 180px;
            }

            .main {
                margin-left: 180px;
                padding: 20px;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .full {
                grid-column: auto;
            }
        }
    </style>
</head>

<body>

<div class="sidebar">
    <div class="brand">⚙ EquipTrack</div>

    <a href="<?php echo e(url('/')); ?>">📊 Dashboard</a>
    <a href="<?php echo e(route('equipment.index')); ?>">▤ Equipment Inventory</a>
    <a href="<?php echo e(route('equipment.create')); ?>" class="active">➕ Add Equipment</a>
    <a href="<?php echo e(url('/#analytics')); ?>">📈 Analytics</a>
    <a href="#">⚙ Settings</a>
</div>

<div class="main">

    <div class="top">
        <div>
            <h1>Add New Equipment</h1>
            <p>Register new equipment in your inventory.</p>
        </div>
        <strong>Administrator</strong>
    </div>

    <div class="card">

        <h2>➕ Equipment Information</h2>

        <?php if($errors->any()): ?>
            <div class="errors">
                <strong>Please check the following:</strong>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('equipment.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-grid">

                <div class="form-group">
                    <label>Equipment Name</label>
                    <input type="text" name="name"
                        value="<?php echo e(old('name')); ?>"
                        placeholder="Enter equipment name" required>
                </div>

                <div class="form-group">
                    <label>Category</label>
                    <input type="text" name="category"
                        value="<?php echo e(old('category')); ?>"
                        placeholder="Enter category" required>
                </div>

                <div class="form-group">
                    <label>Status</label>
                    <select name="status" required>
                        <option value="">Select Status</option>
                        <option value="Available" <?php echo e(old('status') == 'Available' ? 'selected' : ''); ?>>Available</option>
                        <option value="Borrowed" <?php echo e(old('status') == 'Borrowed' ? 'selected' : ''); ?>>Borrowed</option>
                        <option value="Under Maintenance" <?php echo e(old('status') == 'Under Maintenance' ? 'selected' : ''); ?>>Under Maintenance</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Quantity</label>
                    <input type="number" name="quantity"
                        value="<?php echo e(old('quantity', 1)); ?>"
                        min="1" required>
                </div>

                <div class="form-group full">
                    <label>Description</label>
                    <textarea name="description"
                        placeholder="Enter equipment description"><?php echo e(old('description')); ?></textarea>
                </div>

            </div>

            <a href="<?php echo e(route('equipment.index')); ?>" class="btn back">
                ← Back
            </a>

            <button type="submit" class="btn save">
                💾 Save Equipment
            </button>

        </form>

    </div>

</div>

</body>
</html>
<?php /**PATH C:\Users\Cedric\equiptrack\resources\views/equipments/create.blade.php ENDPATH**/ ?>